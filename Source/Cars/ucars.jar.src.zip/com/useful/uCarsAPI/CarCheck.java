package com.useful.uCarsAPI;

import org.bukkit.entity.Minecart;

public abstract interface CarCheck
{
  public abstract Boolean isACar(Minecart paramMinecart);
}
