package com.useful.uCarsAPI;

import org.bukkit.inventory.ItemStack;

public abstract interface ItemCarCheck
{
  public abstract Boolean isACar(ItemStack paramItemStack);
}
