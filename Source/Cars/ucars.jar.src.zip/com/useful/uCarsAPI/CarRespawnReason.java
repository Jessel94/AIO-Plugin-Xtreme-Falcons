package com.useful.uCarsAPI;

public enum CarRespawnReason
{
  TELEPORT,  CUSTOM;
}
